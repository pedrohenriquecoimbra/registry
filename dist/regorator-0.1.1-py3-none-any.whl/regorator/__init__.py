from . import core, version
from .core.main import *
